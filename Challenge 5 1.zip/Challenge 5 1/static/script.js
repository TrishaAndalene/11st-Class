document.addEventListener("DOMContentLoaded", () => {

        const request = new XMLHttpRequest();
        request.onload = function() {
            const data = JSON.parse(this.responseText);
            
            let type = Object.values(data.types);
            let current_choice = "characters";
            let chara = Object.values(data.char);
            let current_char = chara[0];

            let n = 0;
            for (n > -100; n++;){
                if (n === 3){
                    n = 0;
                };

                if (current_choice === "artifacts"){
                    pass
                } else if (current_choice === "characters"){
                    let current_char = chara[n]
                    document.querySelector("#name").innerHTML = "Name : " + current_char.name;
                    document.querySelector("#title").innerHTML = "Title : " + current_char.title;
                    document.querySelector("#vision").innerHTML = "Vision : " + current_char.vision;
                    document.querySelector("#nation").innerHTML = "Nation : " + current_char.nation;
                    document.querySelector("#affli").innerHTML = "Affiliation : " + current_char.affiliation;
                    document.querySelector("#star").innerHTML = "Rarity : " + current_char.rarity;
                } else if (current_choice === "nations"){
                    let map = Object.keys(data.map);
                    let current_map = map[0];
                    if (current_map === "monstadt"){
                        pass
                    } else if (current_map === "liyue"){
                        pass
                    } else if (current_map === "inazuma"){
                        pass
                    }
                }

            }
            }
            // console.log(Object.keys(data.types))
            // conditional
        request.open("GET", `http://127.0.0.1:5000/data`);
        request.send();

        return false;
    }
)