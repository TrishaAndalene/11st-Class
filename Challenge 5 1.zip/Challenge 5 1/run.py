from flask import Flask, jsonify, render_template
import json

# create engine
app = Flask(__name__)

# route
@app.route("/")
@app.route("/home")
def home():
    return render_template("index.html")

@app.route("/char")
def char_card():
    return render_template("char.html")

# api gateaway
@app.route("/data")
def data() :
    try :
        with open("data.json") as file :
            data = json.load(file)
    except :
        return jsonify({
            "status" : False
        })
    else :
        response = jsonify(data)
        response.headers.add("Access-Control-Allow-Origin", "*")
        return response

# starter
app.run(debug=True)