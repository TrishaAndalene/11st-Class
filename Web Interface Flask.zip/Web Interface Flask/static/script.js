document.addEventListener('DOMContentLoaded', () => {

    document.querySelector('.menu-toggle').
    addEventListener('click', function(){
        document.querySelector('.menu-nav').
        classList.toggle('clicked');
    })

    let text_one = document.getElementById('one');
    let moon = document.getElementById('moon')

    window.addEventListener('scroll', function(){
        let value = window.scrollY;
        moon.style.top = value*2 + 'px';
        text_one.style.marginRight = value * 4 + 'px';
    })

})