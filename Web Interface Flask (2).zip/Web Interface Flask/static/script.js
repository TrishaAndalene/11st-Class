document.addEventListener('DOMContentLoaded', () => {

    document.querySelector('.menu-toggle').
    addEventListener('click', function(){
        document.querySelector('.menu-nav').
        classList.toggle('clicked');
    })

    let text_one = document.getElementById('one');
    let moon = document.getElementById('moon')

    window.addEventListener('scroll', function(){
        let value = window.scrollY;
        moon.style.top = value*2 + 'px';
        text_one.style.marginRight = value * 4 + 'px';
    })

    function openChar(evnt, cityName){
        var i, tabcontent, tablinks;

        tabcontent = document.getElementsByClassName("tab-char");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }

        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }

        document.getElementById(cityName).style.display = "block";
        evnt.currentTarget.className += " active";
    }

})