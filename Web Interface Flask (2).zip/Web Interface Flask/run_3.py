from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
@app.route("/home")
def home():
    return render_template('main.html')

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/gallery")
def intro():
    return render_template("character.html")

@app.route("/register")
def register():
    return render_template("register.html")

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/enter", methods=["POST"])
def enter():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("pass")
        if email == "admin@gmail.com" and password == "123456":
            return render_template("preview.html")
        return render_template("register.html")
    return render_template("register.html")

@app.route("/reg")
def reg():
    return render_template("preview.html")

@app.route("/preview")
def preview():
    return render_template("preview.html")

if __name__ == "__main__":
    app.run(debug=True)